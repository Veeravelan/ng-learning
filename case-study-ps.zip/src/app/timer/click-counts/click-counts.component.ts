import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-click-counts',
  templateUrl: './click-counts.component.html',
  styleUrls: ['./click-counts.component.scss']
})
export class ClickCountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
