import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-get-timer',
  templateUrl: './get-timer.component.html',
  styleUrls: ['./get-timer.component.scss']
})
export class GetTimerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
