import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-show-timer',
  templateUrl: './show-timer.component.html',
  styleUrls: ['./show-timer.component.scss']
})
export class ShowTimerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
