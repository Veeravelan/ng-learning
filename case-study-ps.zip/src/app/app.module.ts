import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';

import { AppRoutingModule } from './app-routing.module';
import { HttpClientModule } from '@angular/common/http';
import { AppComponent } from './app.component';
import { FloatingBannerComponent } from './floating-banner/floating-banner.component';
import { EcomCatComponent } from './ecom-cat/ecom-cat.component';
import { TimerComponent } from './timer/timer.component';
import { ShowTimerComponent } from './timer/show-timer/show-timer.component';
import { GetTimerComponent } from './timer/get-timer/get-timer.component';
import { LogTimeComponent } from './timer/log-time/log-time.component';
import { ClickCountsComponent } from './timer/click-counts/click-counts.component';
import { SubTimerComponent } from './sub-timer/sub-timer.component';

import { SubGetTimerComponent } from './sub-timer/sub-get-timer/sub-get-timer.component';
import { SubLogTimerComponent } from './sub-timer/sub-log-timer/sub-log-timer.component';
import { SubShowTimerComponent } from './sub-timer/sub-show-timer/sub-show-timer.component';
import { StudentMarksComponent } from './student-marks/student-marks.component';
import { DynamicContentComponent } from './dynamic-content/dynamic-content.component';
import { SubClickCountsComponent } from './sub-timer/sub-click-counts/sub-click-counts.component';

@NgModule({
  declarations: [
    AppComponent,
    FloatingBannerComponent,
    EcomCatComponent,
    TimerComponent,
    ShowTimerComponent,
    GetTimerComponent,
    LogTimeComponent,
    ClickCountsComponent,
    SubTimerComponent,
    SubClickCountsComponent,
    SubGetTimerComponent,
    SubLogTimerComponent,
    SubShowTimerComponent,
    StudentMarksComponent,
    DynamicContentComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
