import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-floating-banner',
  templateUrl: './floating-banner.component.html',
  styleUrls: ['./floating-banner.component.scss']
})
export class FloatingBannerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
