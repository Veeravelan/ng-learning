import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-show-timer',
  templateUrl: './sub-show-timer.component.html',
  styleUrls: ['./sub-show-timer.component.scss']
})
export class SubShowTimerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
