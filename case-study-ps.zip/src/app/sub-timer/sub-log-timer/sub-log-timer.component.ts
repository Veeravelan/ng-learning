import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-log-timer',
  templateUrl: './sub-log-timer.component.html',
  styleUrls: ['./sub-log-timer.component.scss']
})
export class SubLogTimerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
