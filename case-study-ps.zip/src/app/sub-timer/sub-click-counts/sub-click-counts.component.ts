import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-click-counts',
  templateUrl: './sub-click-counts.component.html',
  styleUrls: ['./sub-click-counts.component.scss']
})
export class SubClickCountsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
