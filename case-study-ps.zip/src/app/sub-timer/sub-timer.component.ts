import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-timer',
  templateUrl: './sub-timer.component.html',
  styleUrls: ['./sub-timer.component.scss']
})
export class SubTimerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
