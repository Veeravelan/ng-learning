import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-sub-get-timer',
  templateUrl: './sub-get-timer.component.html',
  styleUrls: ['./sub-get-timer.component.scss']
})
export class SubGetTimerComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
